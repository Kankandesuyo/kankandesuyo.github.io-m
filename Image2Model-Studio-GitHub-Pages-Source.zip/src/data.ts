import type { ModelOption } from './types';

export const generationSteps = [
  'Analyzing image',
  'Estimating depth',
  'Reconstructing mesh',
  'Generating texture',
  'Exporting GLB',
] as const;

export const sampleModels: ModelOption[] = [
  { id: 'chair', name: 'Chair', file: '/models/chair.glb', hint: 'Furniture silhouette' },
  { id: 'shoe', name: 'Shoe', file: '/models/shoe.glb', hint: 'Product object' },
  { id: 'toy', name: 'Toy', file: '/models/toy.glb', hint: 'Stylized object' },
];

export const aiProviders = [
  {
    name: 'TripoSR',
    description: 'Fast single-image 3D reconstruction pipeline for image-to-mesh workflows.',
  },
  {
    name: 'Stable Fast 3D',
    description: 'High-speed asset generation path for preview-first 3D object creation.',
  },
  {
    name: 'Hunyuan3D',
    description: 'Advanced image-to-3D generation option for future textured mesh output.',
  },
  {
    name: 'TRELLIS',
    description: 'Structured 3D asset generation route for higher-fidelity reconstruction.',
  },
];
