export type UploadedImage = {
  file: File;
  url: string;
  width: number;
  height: number;
};

export type GenerationStatus = 'idle' | 'running' | 'complete';

export type ModelOption = {
  id: string;
  name: string;
  file: string;
  hint: string;
};
