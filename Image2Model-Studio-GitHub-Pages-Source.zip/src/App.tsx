import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowDownToLine,
  Box,
  Check,
  CircleGauge,
  Download,
  Expand,
  FileImage,
  ImageUp,
  Languages,
  Lightbulb,
  Loader2,
  Maximize2,
  Play,
  RefreshCcw,
  Sparkles,
  Upload,
  WandSparkles,
} from 'lucide-react';
import { aiProviders, generationSteps, sampleModels } from './data';
import type { GenerationStatus, ModelOption, UploadedImage } from './types';

const ACCEPTED_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
type Language = 'en' | 'zh';

const copy = {
  en: {
    nav: { studio: 'Studio', models: 'Models', roadmap: 'Roadmap', docs: 'Docs', cta: 'Start Creating' },
    hero: {
      subtitle: 'Upload a 2D image and preview it as an interactive 3D model',
      roadmap: 'AI roadmap',
      live: 'Live preview workspace',
      liveSub: 'Static demo with local sample GLB output',
      drop: 'Drop source image',
    },
    upload: {
      title: 'Image Upload',
      subtitle: 'Click or drag a source image into the studio.',
      empty: 'Upload JPG, PNG, or WEBP',
      emptySub: 'Use a clean object image for the best simulated result preview.',
      file: 'File',
      size: 'Size',
      dimensions: 'Dimensions',
      invalid: 'Please upload a JPG, PNG, or WEBP image.',
      unreadable: 'The image could not be read. Please try another file.',
    },
    generation: {
      title: 'Generation Flow',
      subtitle: 'Five-step static simulation before loading the sample GLB.',
      action: 'Generate 3D Model',
      states: { done: 'Done', running: 'Running', queued: 'Queued' },
      steps: ['Analyzing image', 'Estimating depth', 'Reconstructing mesh', 'Generating texture', 'Exporting GLB'],
    },
    viewer: {
      title: '3D Model Preview',
      subtitle: 'Rotate, zoom, adjust lighting, and inspect the generated GLB output.',
      emptyTitle: 'Model preview appears after generation',
      emptySub: 'Upload an image, run the simulated pipeline, then inspect the local sample GLB model.',
      autoRotate: 'Auto rotate',
      light: 'Light',
      fullscreen: 'Fullscreen',
      background: 'Set background',
      models: { chair: 'Chair', shoe: 'Shoe', toy: 'Toy' },
      modelAlt: 'sample 3D model',
    },
    downloads: {
      title: 'Model Downloads',
      subtitle: 'Export-ready actions for the generated asset.',
      glb: 'Download GLB',
      obj: 'Download OBJ',
      stl: 'Download STL',
      comingSoon: 'Coming Soon',
      runFirst: 'Run generation first',
      hints: { chair: 'Furniture silhouette', shoe: 'Product object', toy: 'Stylized object' },
    },
    roadmap: {
      title: 'Future AI Integrations',
      subtitle: 'The first release is static. These providers are reserved as integration points for a later backend or serverless proxy.',
      providers: [
        'Fast single-image 3D reconstruction pipeline for image-to-mesh workflows.',
        'High-speed asset generation path for preview-first 3D object creation.',
        'Advanced image-to-3D generation option for future textured mesh output.',
        'Structured 3D asset generation route for higher-fidelity reconstruction.',
      ],
    },
    docs: {
      title: 'Static-first architecture',
      body: 'This demo uses local browser state, local image previews, a simulated generation queue, and public GLB files. No backend, database, API routes, server actions, or embedded API keys are required.',
      items: [
        'Upload validation happens in the browser.',
        'Generation progress is simulated with React state.',
        'Sample GLB assets are served from public/models.',
        'Future AI calls should go through a separate secure backend or serverless proxy.',
      ],
    },
    footer: { demo: 'Static frontend demo', ready: 'GLB preview ready', waiting: 'Awaiting image input' },
  },
  zh: {
    nav: { studio: '工作台', models: '模型', roadmap: '路线图', docs: '说明', cta: '开始创作' },
    hero: {
      subtitle: '上传二维图片，并将其预览为可交互的三维模型',
      roadmap: 'AI 路线图',
      live: '实时预览工作台',
      liveSub: '静态 Demo，使用本地示例 GLB 输出',
      drop: '拖入源图片',
    },
    upload: {
      title: '图片上传',
      subtitle: '点击或拖拽图片到工作台。',
      empty: '上传 JPG、PNG 或 WEBP',
      emptySub: '建议使用主体清晰的物体图片，模拟预览效果更好。',
      file: '文件名',
      size: '大小',
      dimensions: '尺寸',
      invalid: '请上传 JPG、PNG 或 WEBP 图片。',
      unreadable: '图片无法读取，请换一张图片重试。',
    },
    generation: {
      title: '生成流程',
      subtitle: '加载示例 GLB 前，先模拟五步生成过程。',
      action: '生成 3D 模型',
      states: { done: '完成', running: '进行中', queued: '等待中' },
      steps: ['分析图片', '估计深度', '重建网格', '生成纹理', '导出 GLB'],
    },
    viewer: {
      title: '3D 模型预览',
      subtitle: '旋转、缩放、调整光照，并检查生成后的 GLB 输出。',
      emptyTitle: '生成完成后显示模型预览',
      emptySub: '上传图片并运行模拟流程后，即可查看本地示例 GLB 模型。',
      autoRotate: '自动旋转',
      light: '光照',
      fullscreen: '全屏',
      background: '设置背景',
      models: { chair: '椅子', shoe: '鞋子', toy: '玩具' },
      modelAlt: '示例 3D 模型',
    },
    downloads: {
      title: '模型下载',
      subtitle: '生成资产的导出入口。',
      glb: '下载 GLB',
      obj: '下载 OBJ',
      stl: '下载 STL',
      comingSoon: '即将推出',
      runFirst: '请先运行生成流程',
      hints: { chair: '家具轮廓', shoe: '产品物体', toy: '风格化物体' },
    },
    roadmap: {
      title: '后续 AI 接入',
      subtitle: '第一版是纯静态页面。这些模型会作为后续后端或 Serverless 代理的接入预留点。',
      providers: [
        '面向图生网格流程的快速单图 3D 重建方案。',
        '适合优先快速预览的高速 3D 资产生成路径。',
        '面向未来高质量纹理网格输出的图生 3D 方案。',
        '适合更高保真重建的结构化 3D 资产生成路线。',
      ],
    },
    docs: {
      title: '静态优先架构',
      body: '这个 Demo 只使用浏览器本地状态、本地图片预览、模拟生成队列和 public 目录中的 GLB 文件。不需要后端、数据库、API Routes、Server Actions 或内置 API Key。',
      items: [
        '上传校验在浏览器中完成。',
        '生成进度由 React 状态模拟。',
        '示例 GLB 资源从 public/models 提供。',
        '未来真实 AI 调用应通过安全后端或 Serverless 代理完成。',
      ],
    },
    footer: { demo: '静态前端 Demo', ready: 'GLB 预览已就绪', waiting: '等待图片输入' },
  },
} satisfies Record<Language, object>;

type AppCopy = typeof copy.en;

function formatBytes(bytes: number) {
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / 1024 ** index).toFixed(index === 0 ? 0 : 1)} ${units[index]}`;
}

function withBase(path: string) {
  const base = import.meta.env.BASE_URL.replace(/\/$/, '');
  return `${base}${path}`;
}

function Header({ language, onLanguageChange, t }: { language: Language; onLanguageChange: (language: Language) => void; t: AppCopy }) {
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-ink/78 backdrop-blur-2xl">
      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <a href="#top" className="flex items-center gap-3">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg border border-neon/25 bg-neon/10 text-neon">
            <Box size={18} />
          </span>
          <span className="text-sm font-semibold tracking-wide text-white">Image2Model Studio</span>
        </a>
        <div className="hidden items-center gap-7 text-sm text-slate-400 md:flex">
          <a className="transition hover:text-white" href="#studio">
            {t.nav.studio}
          </a>
          <a className="transition hover:text-white" href="#models">
            {t.nav.models}
          </a>
          <a className="transition hover:text-white" href="#roadmap">
            {t.nav.roadmap}
          </a>
          <a className="transition hover:text-white" href="#docs">
            {t.nav.docs}
          </a>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 rounded-lg border border-white/10 bg-white/[0.04] p-1">
            <Languages size={15} className="ml-2 text-slate-500" />
            {(['en', 'zh'] as const).map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => onLanguageChange(item)}
                className={`rounded-md px-2.5 py-1.5 text-xs font-semibold transition ${
                  language === item ? 'bg-neon text-slate-950' : 'text-slate-400 hover:text-white'
                }`}
              >
                {item === 'en' ? 'EN' : '中文'}
              </button>
            ))}
          </div>
          <a
            href="#studio"
            className="rounded-lg border border-white/12 bg-white/8 px-4 py-2 text-sm font-medium text-white transition hover:border-neon/45 hover:bg-neon/10"
          >
            {t.nav.cta}
          </a>
        </div>
      </nav>
    </header>
  );
}

function Hero({ t }: { t: AppCopy }) {
  return (
    <section id="top" className="mx-auto grid max-w-7xl gap-10 px-4 pb-10 pt-16 sm:px-6 lg:grid-cols-[0.85fr_1.15fr] lg:px-8 lg:pb-14 lg:pt-20">
      <div className="flex flex-col justify-center">
        <h1 className="max-w-3xl text-5xl font-semibold leading-[1.02] text-white sm:text-6xl lg:text-7xl">
          Image2Model Studio
        </h1>
        <p className="mt-6 max-w-xl text-lg leading-8 text-slate-300">
          {t.hero.subtitle}
        </p>
        <div className="mt-8 flex flex-wrap items-center gap-3">
          <a
            href="#studio"
            className="inline-flex items-center gap-2 rounded-lg bg-neon px-5 py-3 text-sm font-semibold text-slate-950 shadow-focus-glow transition hover:-translate-y-0.5"
          >
            <Play size={17} fill="currentColor" />
            {t.nav.cta}
          </a>
          <a
            href="#roadmap"
            className="inline-flex items-center gap-2 rounded-lg border border-white/12 bg-white/7 px-5 py-3 text-sm font-semibold text-white transition hover:border-cyanline/45"
          >
            <Sparkles size={17} />
            {t.hero.roadmap}
          </a>
        </div>
      </div>
      <div className="relative min-h-[360px] overflow-hidden rounded-[22px] border border-white/10 bg-panel/70 shadow-studio">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_45%_15%,rgba(98,217,255,0.16),transparent_34%),linear-gradient(135deg,rgba(88,243,200,0.08),transparent_38%)]" />
        <div className="relative grid h-full grid-rows-[auto_1fr_auto] p-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div>
              <p className="text-sm font-medium text-white">{t.hero.live}</p>
              <p className="text-xs text-slate-500">{t.hero.liveSub}</p>
            </div>
            <RefreshCcw className="text-neon" size={18} />
          </div>
          <div className="grid gap-4 py-4 sm:grid-cols-[0.8fr_1.2fr]">
            <div className="rounded-xl border border-dashed border-white/16 bg-white/[0.04] p-4">
              <div className="flex h-full min-h-40 flex-col items-center justify-center gap-3 text-center">
                <ImageUp className="text-neon" size={34} />
                <p className="text-sm font-medium text-white">{t.hero.drop}</p>
                <p className="text-xs text-slate-500">JPG, PNG, WEBP</p>
              </div>
            </div>
            <div className="relative rounded-xl border border-cyanline/20 bg-black/35">
              <div className="absolute inset-x-6 top-6 h-px bg-cyanline/40" />
              <div className="flex h-full min-h-40 items-center justify-center">
                <Box size={72} className="text-cyanline/80" />
              </div>
            </div>
          </div>
          <div className="grid grid-cols-5 gap-2">
            {t.generation.steps.map((step, index) => (
              <div key={step} className="h-1.5 overflow-hidden rounded-full bg-white/8">
                <div className="h-full rounded-full bg-neon" style={{ width: `${index * 18 + 22}%` }} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

type UploadPanelProps = {
  image: UploadedImage | null;
  error: string;
  onUpload: (file: File) => void;
  t: AppCopy;
};

function UploadPanel({ image, error, onUpload, t }: UploadPanelProps) {
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const pickFile = (file?: File) => {
    if (!file) return;
    onUpload(file);
  };

  return (
    <section className="rounded-2xl border border-white/10 bg-panel/88 p-5 shadow-studio">
      <div className="mb-5 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-white">{t.upload.title}</h2>
          <p className="mt-1 text-sm text-slate-500">{t.upload.subtitle}</p>
        </div>
        <FileImage className="text-neon" size={22} />
      </div>
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        onDragOver={(event) => {
          event.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(event) => {
          event.preventDefault();
          setDragging(false);
          pickFile(event.dataTransfer.files[0]);
        }}
        className={`group flex min-h-[280px] w-full flex-col items-center justify-center rounded-xl border border-dashed p-5 text-center transition ${
          dragging
            ? 'border-neon bg-neon/10 shadow-focus-glow'
            : 'border-white/16 bg-white/[0.035] hover:border-cyanline/45 hover:bg-white/[0.055]'
        }`}
      >
        {image ? (
          <div className="w-full">
            <img src={image.url} alt="Uploaded preview" className="mx-auto aspect-[4/3] max-h-64 w-full rounded-lg object-cover" />
            <div className="mt-4 grid gap-2 rounded-lg border border-white/10 bg-black/25 p-3 text-left text-sm">
              <div className="flex justify-between gap-4">
                <span className="text-slate-500">{t.upload.file}</span>
                <span className="truncate text-white">{image.file.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">{t.upload.size}</span>
                <span className="text-white">{formatBytes(image.file.size)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">{t.upload.dimensions}</span>
                <span className="text-white">
                  {image.width} x {image.height}
                </span>
              </div>
            </div>
          </div>
        ) : (
          <>
            <span className="mb-5 flex h-16 w-16 items-center justify-center rounded-2xl border border-neon/30 bg-neon/10 text-neon transition group-hover:scale-105">
              <Upload size={28} />
            </span>
            <span className="text-base font-semibold text-white">{t.upload.empty}</span>
            <span className="mt-2 max-w-xs text-sm leading-6 text-slate-500">{t.upload.emptySub}</span>
          </>
        )}
      </button>
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="hidden"
        onChange={(event) => pickFile(event.target.files?.[0])}
      />
      {error ? <p className="mt-3 text-sm text-red-300">{error}</p> : null}
    </section>
  );
}

type GenerationPanelProps = {
  status: GenerationStatus;
  activeStep: number;
  canGenerate: boolean;
  onGenerate: () => void;
  t: AppCopy;
};

function GenerationPanel({ status, activeStep, canGenerate, onGenerate, t }: GenerationPanelProps) {
  return (
    <section className="rounded-2xl border border-white/10 bg-panel/88 p-5 shadow-studio">
      <div className="mb-5 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-white">{t.generation.title}</h2>
          <p className="mt-1 text-sm text-slate-500">{t.generation.subtitle}</p>
        </div>
        <WandSparkles className="text-cyanline" size={22} />
      </div>
      <div className="space-y-3">
        {t.generation.steps.map((step, index) => {
          const completed = status === 'complete' || activeStep > index;
          const running = status === 'running' && activeStep === index;
          return (
            <div key={step} className="rounded-xl border border-white/10 bg-white/[0.035] p-3">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span
                    className={`flex h-8 w-8 items-center justify-center rounded-lg ${
                      completed ? 'bg-neon text-slate-950' : running ? 'bg-cyanline/15 text-cyanline' : 'bg-white/8 text-slate-500'
                    }`}
                  >
                    {completed ? <Check size={16} /> : running ? <Loader2 className="animate-spin" size={16} /> : index + 1}
                  </span>
                  <span className="text-sm font-medium text-white">{step}</span>
                </div>
                <span className="text-xs text-slate-500">
                  {completed ? t.generation.states.done : running ? t.generation.states.running : t.generation.states.queued}
                </span>
              </div>
              <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/8">
                <div
                  className={`h-full rounded-full transition-all duration-700 ${completed || running ? 'bg-neon' : 'bg-white/10'}`}
                  style={{ width: completed ? '100%' : running ? '72%' : '0%' }}
                />
              </div>
            </div>
          );
        })}
      </div>
      <button
        type="button"
        disabled={!canGenerate || status === 'running'}
        onClick={onGenerate}
        className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-neon px-5 py-3 text-sm font-semibold text-slate-950 transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:bg-slate-600 disabled:text-slate-300 disabled:hover:translate-y-0"
      >
        {status === 'running' ? <Loader2 className="animate-spin" size={17} /> : <WandSparkles size={17} />}
        {t.generation.action}
      </button>
    </section>
  );
}

type ViewerProps = {
  status: GenerationStatus;
  model: ModelOption;
  autoRotate: boolean;
  background: string;
  exposure: number;
  onAutoRotate: (value: boolean) => void;
  onBackground: (value: string) => void;
  onExposure: (value: number) => void;
  onModel: (model: ModelOption) => void;
  t: AppCopy;
};

function ModelViewerPanel({ status, model, autoRotate, background, exposure, onAutoRotate, onBackground, onExposure, onModel, t }: ViewerProps) {
  const shellRef = useRef<HTMLDivElement>(null);
  const ready = status === 'complete';

  return (
    <section ref={shellRef} id="models" className="rounded-2xl border border-white/10 bg-panel/88 p-5 shadow-studio lg:self-start">
      <div className="mb-5 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-lg font-semibold text-white">{t.viewer.title}</h2>
          <p className="mt-1 text-sm text-slate-500">{t.viewer.subtitle}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {sampleModels.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => onModel(item)}
              className={`rounded-lg border px-3 py-2 text-xs font-semibold transition ${
                item.id === model.id ? 'border-neon bg-neon/12 text-neon' : 'border-white/10 bg-white/6 text-slate-300 hover:border-white/20'
              }`}
            >
              {t.viewer.models[item.id as keyof typeof t.viewer.models]}
            </button>
          ))}
        </div>
      </div>
      <div className="relative min-h-[460px] overflow-hidden rounded-xl border border-cyanline/18" style={{ background }}>
        {ready ? (
          <model-viewer
            src={withBase(model.file)}
            alt={`${t.viewer.models[model.id as keyof typeof t.viewer.models]} ${t.viewer.modelAlt}`}
            camera-controls
            auto-rotate={autoRotate ? 'true' : undefined}
            shadow-intensity="0.65"
            exposure={String(exposure)}
            environment-image="neutral"
            interaction-prompt="none"
            touch-action="pan-y"
            loading="eager"
            className="h-[460px] w-full"
          />
        ) : (
          <div className="flex h-[460px] flex-col items-center justify-center p-6 text-center">
            <span className="mb-5 flex h-20 w-20 items-center justify-center rounded-2xl border border-cyanline/25 bg-cyanline/10 text-cyanline">
              <Box size={42} />
            </span>
            <p className="text-lg font-semibold text-white">{t.viewer.emptyTitle}</p>
            <p className="mt-2 max-w-md text-sm leading-6 text-slate-500">{t.viewer.emptySub}</p>
          </div>
        )}
        <div className="pointer-events-none absolute inset-x-0 top-0 h-20 bg-gradient-to-b from-black/22 to-transparent" />
      </div>
      <div className="mt-5 grid gap-4 xl:grid-cols-[1fr_auto]">
        <div className="grid gap-3 rounded-xl border border-white/10 bg-white/[0.035] p-4 md:grid-cols-3">
          <label className="flex items-center justify-between gap-3 rounded-lg bg-black/20 px-3 py-2 text-sm text-slate-300">
            <span className="inline-flex items-center gap-2">
              <RefreshCcw size={15} className="text-neon" />
              {t.viewer.autoRotate}
            </span>
            <input type="checkbox" checked={autoRotate} onChange={(event) => onAutoRotate(event.target.checked)} className="h-4 w-4 accent-neon" />
          </label>
          <label className="flex items-center gap-3 rounded-lg bg-black/20 px-3 py-2 text-sm text-slate-300">
            <Lightbulb size={15} className="text-cyanline" />
            <span>{t.viewer.light}</span>
            <input
              type="range"
              min="0.4"
              max="2"
              step="0.1"
              value={exposure}
              onChange={(event) => onExposure(Number(event.target.value))}
              className="min-w-0 flex-1 accent-neon"
            />
          </label>
          <button
            type="button"
            onClick={() => shellRef.current?.requestFullscreen()}
            className="inline-flex items-center justify-center gap-2 rounded-lg border border-white/10 bg-black/20 px-3 py-2 text-sm font-medium text-white transition hover:border-cyanline/45"
          >
            <Maximize2 size={15} />
            {t.viewer.fullscreen}
          </button>
        </div>
        <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.035] p-3">
          {['#05070d', '#111827', '#f8fafc', '#d8fff5'].map((color) => (
            <button
              key={color}
              type="button"
              aria-label={`${t.viewer.background} ${color}`}
              onClick={() => onBackground(color)}
              className={`h-8 w-8 rounded-lg border transition ${background === color ? 'border-neon ring-2 ring-neon/30' : 'border-white/16'}`}
              style={{ backgroundColor: color }}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

function DownloadPanel({ status, model, t }: { status: GenerationStatus; model: ModelOption; t: AppCopy }) {
  const ready = status === 'complete';
  return (
    <section className="rounded-2xl border border-white/10 bg-panel/88 p-5 shadow-studio">
      <div className="mb-5 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-white">{t.downloads.title}</h2>
          <p className="mt-1 text-sm text-slate-500">{t.downloads.subtitle}</p>
        </div>
        <ArrowDownToLine className="text-neon" size={22} />
      </div>
      <div className="grid gap-3">
        <a
          href={ready ? withBase(model.file) : undefined}
          download={ready ? `${model.id}.glb` : undefined}
          aria-disabled={!ready}
          className={`flex items-center justify-between rounded-xl border p-4 transition ${
            ready ? 'border-neon/35 bg-neon/10 text-white hover:bg-neon/15' : 'pointer-events-none border-white/10 bg-white/[0.035] text-slate-500'
          }`}
        >
          <span>
            <span className="block text-sm font-semibold">{t.downloads.glb}</span>
            <span className="mt-1 block text-xs text-slate-500">
              {ready ? t.downloads.hints[model.id as keyof typeof t.downloads.hints] : t.downloads.runFirst}
            </span>
          </span>
          <Download size={18} />
        </a>
        {['OBJ', 'STL'].map((format) => (
          <div key={format} className="flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.035] p-4 text-slate-500">
            <span>
              <span className="block text-sm font-semibold">{format === 'OBJ' ? t.downloads.obj : t.downloads.stl}</span>
              <span className="mt-1 block text-xs">{t.downloads.comingSoon}</span>
            </span>
            <CircleGauge size={18} />
          </div>
        ))}
      </div>
    </section>
  );
}

function Roadmap({ t }: { t: AppCopy }) {
  return (
    <section id="roadmap" className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="mb-7 flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <h2 className="text-2xl font-semibold text-white">{t.roadmap.title}</h2>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">{t.roadmap.subtitle}</p>
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {aiProviders.map((provider, index) => (
          <article key={provider.name} className="rounded-2xl border border-white/10 bg-panel/78 p-5">
            <div className="mb-5 flex h-10 w-10 items-center justify-center rounded-lg border border-cyanline/25 bg-cyanline/10 text-cyanline">
              <Expand size={18} />
            </div>
            <h3 className="text-base font-semibold text-white">{provider.name}</h3>
            <p className="mt-3 text-sm leading-6 text-slate-500">{t.roadmap.providers[index]}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

function DocsSection({ t }: { t: AppCopy }) {
  return (
    <section id="docs" className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8">
      <div className="rounded-2xl border border-white/10 bg-[linear-gradient(135deg,rgba(88,243,200,0.08),rgba(98,217,255,0.05)_45%,rgba(255,255,255,0.03))] p-6 md:p-8">
        <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <h2 className="text-2xl font-semibold text-white">{t.docs.title}</h2>
            <p className="mt-3 text-sm leading-7 text-slate-400">{t.docs.body}</p>
          </div>
          <div className="grid gap-3 text-sm">
            {t.docs.items.map((item) => (
              <div key={item} className="flex items-center gap-3 rounded-xl border border-white/10 bg-black/18 p-3 text-slate-300">
                <Check className="shrink-0 text-neon" size={16} />
                {item}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export default function App() {
  const [language, setLanguage] = useState<Language>('en');
  const [image, setImage] = useState<UploadedImage | null>(null);
  const [error, setError] = useState('');
  const [status, setStatus] = useState<GenerationStatus>('idle');
  const [activeStep, setActiveStep] = useState(0);
  const [model, setModel] = useState(sampleModels[0]);
  const [autoRotate, setAutoRotate] = useState(true);
  const [background, setBackground] = useState('#05070d');
  const [exposure, setExposure] = useState(1);
  const t = copy[language];

  useEffect(() => {
    return () => {
      if (image) URL.revokeObjectURL(image.url);
    };
  }, [image]);

  useEffect(() => {
    document.documentElement.lang = language === 'zh' ? 'zh-CN' : 'en';
  }, [language]);

  const handleUpload = (file: File) => {
    setError('');
    if (!ACCEPTED_TYPES.includes(file.type)) {
      setError(t.upload.invalid);
      return;
    }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      setImage((previous) => {
        if (previous) URL.revokeObjectURL(previous.url);
        return { file, url, width: img.naturalWidth, height: img.naturalHeight };
      });
      setStatus('idle');
      setActiveStep(0);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      setError(t.upload.unreadable);
    };
    img.src = url;
  };

  const generate = () => {
    if (!image || status === 'running') return;
    setStatus('running');
    setActiveStep(0);
    generationSteps.forEach((_, index) => {
      window.setTimeout(() => {
        setActiveStep(index);
        if (index === generationSteps.length - 1) {
          window.setTimeout(() => setStatus('complete'), 700);
        }
      }, index * 850);
    });
  };

  const pageState = useMemo(() => ({ ready: status === 'complete' }), [status]);

  return (
    <div className="min-h-screen bg-ink text-slate-100">
      <div className="fixed inset-0 -z-10 bg-[radial-gradient(circle_at_50%_-10%,rgba(88,243,200,0.13),transparent_33%),linear-gradient(180deg,#06080d_0%,#090d15_48%,#05070b_100%)]" />
      <Header language={language} onLanguageChange={setLanguage} t={t} />
      <main>
        <Hero t={t} />
        <section id="studio" className="mx-auto grid max-w-7xl gap-5 px-4 py-8 sm:px-6 lg:grid-cols-[0.9fr_1.35fr] lg:px-8">
          <div className="grid gap-5">
            <UploadPanel image={image} error={error} onUpload={handleUpload} t={t} />
            <GenerationPanel status={status} activeStep={activeStep} canGenerate={Boolean(image)} onGenerate={generate} t={t} />
            <DownloadPanel status={status} model={model} t={t} />
          </div>
          <ModelViewerPanel
            status={status}
            model={model}
            autoRotate={autoRotate}
            background={background}
            exposure={exposure}
            onAutoRotate={setAutoRotate}
            onBackground={setBackground}
            onExposure={setExposure}
            onModel={setModel}
            t={t}
          />
        </section>
        <Roadmap t={t} />
        <DocsSection t={t} />
      </main>
      <footer className="border-t border-white/10 px-4 py-8 text-center text-sm text-slate-600">
        Image2Model Studio · {t.footer.demo} · {pageState.ready ? t.footer.ready : t.footer.waiting}
      </footer>
    </div>
  );
}
