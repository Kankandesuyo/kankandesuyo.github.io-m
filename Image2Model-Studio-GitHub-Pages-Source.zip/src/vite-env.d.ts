/// <reference types="vite/client" />

import type React from 'react';

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'model-viewer': React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement> & {
        src?: string;
        alt?: string;
        'camera-controls'?: boolean | string;
        'auto-rotate'?: boolean | string;
        'shadow-intensity'?: string;
        exposure?: string;
        'environment-image'?: string;
        'interaction-prompt'?: string;
        'touch-action'?: string;
        loading?: 'auto' | 'lazy' | 'eager';
        ar?: boolean | string;
      };
    }
  }
}

declare module 'react' {
  namespace JSX {
    interface IntrinsicElements {
      'model-viewer': React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement> & {
        src?: string;
        alt?: string;
        'camera-controls'?: boolean | string;
        'auto-rotate'?: boolean | string;
        'shadow-intensity'?: string;
        exposure?: string;
        'environment-image'?: string;
        'interaction-prompt'?: string;
        'touch-action'?: string;
        loading?: 'auto' | 'lazy' | 'eager';
        ar?: boolean | string;
      };
    }
  }
}

export {};
