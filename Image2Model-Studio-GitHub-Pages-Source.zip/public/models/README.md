# Sample GLB Models

This folder is reserved for static demo models:

- `chair.glb`
- `shoe.glb`
- `toy.glb`

The first version includes lightweight placeholder GLB files so the static demo can run without a backend. Replace them with real GLB assets when available. Recommended properties:

- Optimized for web preview
- Under 5 MB each for fast GitHub Pages loading
- Textured GLB format, not a separate `.gltf` plus texture folder
- Centered around the origin and scaled to a preview-friendly size
